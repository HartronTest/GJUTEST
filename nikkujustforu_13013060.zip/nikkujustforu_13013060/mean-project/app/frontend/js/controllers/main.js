'use strict';

angular.module('todo')
  .controller('MainCtrl', function ($rootScope) {
	$rootScope.pageTitle = 'Homepage';
  });